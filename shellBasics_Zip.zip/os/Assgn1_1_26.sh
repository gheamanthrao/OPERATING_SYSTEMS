#!/bin/bash
declare -ai arr
i=0
while read n
do
num=0
while [[ $n -gt 0 ]]
do
num=$(expr $num \* 10)
rem=$(expr $n % 10)
num=$(expr $num + $rem)
n=$(expr $n / 10)
done
arr[i]=$num
i=$((i+1))
done < $1
n1=${arr[0]}
n2=${arr[1]}
n=${#arr[@]}
for ((i=1;i<n-1;i++));do
temp1=$n1
temp2=$n2
r=$n2
while [ $r -ne 0 ];do
r=$(( n1%n2 ))
  if [ $r -eq 0 ];then
        break
  else
     ((n1=$n2))
     ((n2=$r))
  fi
done
lcm=`expr $temp1 \* $temp2 / $n2`
n2=${arr[$i+1]}
n1=$lcm
done
echo "LCM : $lcm"


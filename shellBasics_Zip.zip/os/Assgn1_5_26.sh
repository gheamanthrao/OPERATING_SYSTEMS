#!/bin/bash
f=$(basebame -- $1)
for py_file in $(find $f -name '*.py')
do
echo "  "
echo "  "
echo "File name : $py_file"
echo "single line and multiline comments in python file:"
num=1
echo "1.single line comments :"
echo " "
while read -r lines
do 
    if [ "$lines" != "${lines#*#}" ]
        then
            printf '%d\t%s\n' $num "$lines"
    fi
   num=$((num + 1))
done < $py_file
n=1
echo "2.multiple line comments :"
echo " "
while read -r lines
do 
    if [[ $lines == '"""'* ]]
    #starting of multiline
         then
            printf '%d\t%s\n' $n "$lines"
           p=0
           while read -r inside_lines
           do
           
           if [[ $lines == '"""'* ]] #ending of multiline
           then
           printf '%s\n' "$inside_lines"
           break #break from the multiline comments
           else
           printf '%s\n' "$inside_lines"
          
           fi
           p=$((p + 1))
           done 
        fi
       n=$((n + 1))
done < $py_file
done













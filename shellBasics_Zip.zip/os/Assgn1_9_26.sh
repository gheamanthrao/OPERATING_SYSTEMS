touch a.txt
touch b.txt
touch d.txt
touch e.txt
f="$(basename -- $1)"
while read f1 f2
do
echo "$f2" >> a.txt
echo "$f1" >> b.txt  
done < $f    
sort a.txt | uniq -c | sort -nr |  while read count name
do
      if [ ${count} -gt 0 ]
     then
            echo "${name} ${count}" >> e.txt
  fi
done
sort e.txt | sort -k 2nr  | while read line
do
echo "$line"
done
rm e.txt
rm a.txt
i=
declare -i cnt
echo " "
sort b.txt | uniq -c | sort -nr | while read count name
do
      if [ "$count" -gt 1 ]
     then
            echo "${name}"
      else
         i=$(expr $i + 1 )
         echo "$i" >> d.txt
         cnt=$i
  fi
done 
rm b.txt
while read line
do
x=$line
done < d.txt
echo " "
echo "$x"
rm d.txt


#!/bin/bash
mkdir -p "$2"
for x in {a..z};do
> $2/$x.txt
done
for f in $1/*.txt;do
while read n; do
echo $n >> $2/${n:0:1}.txt
done < "${f}"
done
for x in {a..z};do
sort -o $2/$x.txt $2/$x.txt
done

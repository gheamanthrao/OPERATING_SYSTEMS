#!/bin/bash
a=("$@")
s=$1
d=$2
unset a[0]
unset a[1]
for f in $s/*.jsonl; do
    l=${#s}
    fn=`echo ${f:$l+1:-6}`
    jq -n '[inputs]' <$f>$s/$fn.json
done
l=${#s}
r_v=""
r_h=""
for we in "${a[@]}"; do
    r_v="$r_v,$we"
    r_h="$r_h.$we,"
done
r_v=`echo ${r_v:1}`
r_h=`echo ${r_h:0:-1}`
for f in $s/*.json; do
    fn=`echo ${f:$l+1:-5}`
    jq -r ".[] | [$r_h] | @csv" "$f" | sed "1s/^/$r_v\n/" | tr -d '"' > "$d/$fn.csv"
done

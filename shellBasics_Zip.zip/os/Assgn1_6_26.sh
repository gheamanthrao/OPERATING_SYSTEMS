#!/bin/bash
p=()
for((i=2;i<=1000;i++)); do
    p[i]=1
done
for((i=2;i*i<=1000;i++)); do
    if [[ ${p[i]} -eq 1 ]]; then
        for((j=i*i;j<=1000;j+=i));do
            p[j]=0
        done
    fi
done
while read l; do
    l1=`echo ${l:0:-1}`
    int=$(echo "$l1" | awk '{print sqrt($1)}')
    w=${int%.*}
    echo $w
    for((i=2;i<=w;i++)); do
        if [[ ${p[i]} -eq 1 ]]; then
            res=$((l1%i))
            if [[ ${res} -eq 0 ]]; then
                echo -n "$i " >> output.txt
                for((;;)); do
                    rems=$((l1%i))
                    if [[ ${rems} -eq 0 ]]; then
                        l1=$((l1/i))
                    else
                        break
                    fi
                done 
            fi
        fi
    done
    if [[ ${l1} -gt 1 ]]; then
        echo -n "$l1 " >> output.txt
    fi
    echo "" >> "output.txt"
done < "input.txt"
#!/bin/bash 
valid()
{
    un=$1
    if [[ (${#un} -lt 5) || (${#un} -gt 20) ]]; then
        echo "NO" >> "validation_results.txt"
        return
    fi
    if [[ $un =~ [^a-zA-Z0-9] ]]; then
        echo "NO" >> "validation_results.txt"
        return
    fi
    if [[ ! $un =~ [0-9] ]]; then
        echo "NO" >> "validation_results.txt"
        return
    fi
    if [[ ! $un =~ ^[a-zA-Z] ]]; then
        echo "NO" >> "validation_results.txt"
        return
    fi
    while read -r iw; do
    if [[ ${un,,} == *"${iw,,}"* ]]; then
        echo $un
        echo "NO" >> "validation_results.txt"
        return
    fi
    done < "fruits.txt"

    echo "YES" >> "validation_results.txt"
    return
}
while read -r line; do
    valid $line
done < $1

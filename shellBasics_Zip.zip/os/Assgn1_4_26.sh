file=$1
input=$2
touch ouput.txt
while read line; do  if [[ ${line##* } == "$input" ]] ||
        [[ $line == "$input "* ]] || [[ $line == *" $input "* ]] || [[ $line == *" $input\w" ]]; then
    abhi=$(echo "$line" | tr '[:lower:]' '[:upper:]')
    sed 's/[A-Z][^A-Z\n]*[A-Z]\?/\l\0/g' <<<$abhi >>output.txt
else echo "$line" >>output.txt; fi; done <$file
while read line; do echo "$line"; done <output.txt
rm output.txt

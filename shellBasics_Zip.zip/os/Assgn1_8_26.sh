#!/bin/bash
if [ ! -f main.csv ]
then
> main.csv
#echo "Date (dd-mm-yy),Category,Amount,Name" > main.csv
fi
pos=0;
tot=0;
t=0;
for i in "$@"
do
if [ ! $i = "-c" ] && [ ! $i = "-n" ] && [ ! $i = "-s" ] && [ ! $i = "-h" ]
then
tot=$((tot+1));
fi
if [ $tot = 4 ]
then
t=1;
break;
fi
if [ $i = "-c" ] || [ $i = "-n" ] || [ $i = "-s" ] || [ $i = "-h" ]
then
tot=-1;
fi
pos=$((pos+1));
done
if [  $t -ne 0 ]
then
f=0
id1="0";
id2="0";
id3="0";
id4="0";
for k in "$@"
do
if [ $((pos-3)) = $f ] 
then
id1=$k;
fi
if [ $((pos-2)) = $f ] 
then
id2=$k;
fi
if [ $((pos-1)) = $f ] 
then
id3=$k;
fi
if [ $((pos)) = $f ] 
then
id4=$k;
fi
f=$((f+1));
done
echo "$id1,$id2,$id3,$id4" >> main.csv
echo "Inserted $id1,$id2,$id3,$id4";
sort -t, -k 1.7n -k 1.1,1.2n -k 3.4,3.5n main.csv -o main.csv
fi

n=$#;
i=1;
while [ $i -le $n ]
do
IFS=","

if [ ! $1 = "-1" ] && [ $1 = "-c" ]
then
sum=0;
shift 1;
while read f1 f2 f3 f4
do
        if [ ! $1 = "-1" ] && [ $f2 = $1 ]
        then
        sum=$((sum + f3));
        fi
done < main.csv
str=$1;
shift 1;
echo "The total sum under category $str :$sum";
fi

if [ ! $1 = "-1" ] && [ $1 = "-n" ]
then
sum=0;
shift 1;
while read f1 f2 f3 f4
do
        if [ ! $1 = "-1" ] && [ $f4 = $1 ]
        then
        sum=$((sum + f3));
        fi
done < main.csv
st=$1;
shift 1;
echo "The total sum under category $st :$sum";
fi

if [ ! $1 = "-1" ] && [ $1 = "-s" ]
then
shift 1;
if [ ! $1 = "-1" ] && [ $1 = "date" ]
then
sort -t, -k 1.7n -k 1.1,1.2n -k 3.4,3.5n main.csv -o main.csv
fi

if [ ! $1 = "-1" ] && [ $1 = "category" ]
then
sort -k2 -t, main.csv -o main.csv
fi

if [ ! $1 = "-1" ] && [ $1 = "amount" ]
then
sort -k3 -n -t, main.csv -o main.csv
fi

if [ ! $1 = "-1" ] && [ $1 = "name" ]
then
sort -k4 -t, main.csv -o main.csv
fi
shift 1;
fi

if [ ! $1 = "1" ] && [ $1 = "-h" ]
then
tput bold
echo "NAME";
tput sgr0
echo "   Assgn1_8_26 - CSV File Operations\n";

tput bold
echo "SYNOPSIS";
tput sgr0
echo "	 sh Assgn1_8_26.sh [OPTION] CATEGORYNAME..  DATE CATEGORY AMOUNT NAME\n";

tput bold
echo "DESCRIPTION";
tput sgr0
echo "	     Create the CSV File if not exists\n";
echo "	     -c,  -category   displays total amount spend in that category\n";
echo "	     -n,  -name  displays total amount spend by that person name\n";
echo "	     -s,  -sortcolumn  sort the csv by column\n";
echo "	     -h,  -help displays this help and exit\n";
fi

i=$((i+1))
done

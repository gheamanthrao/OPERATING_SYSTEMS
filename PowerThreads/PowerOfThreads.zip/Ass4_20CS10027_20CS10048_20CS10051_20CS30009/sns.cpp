#include <iostream>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <fstream>
#include <sstream>
#include <string>
#include <bits/stdc++.h>
#include <thread>
#include <random>
#include <set>
#define MAX_NODES 37700
using namespace std;

struct action
{
    /* data */
    int nid;
    int aid;
    int at;
    time_t t;
};
typedef struct
{
    int id;
    int degree;
    vector<int> nb;
    int cat;
} Node;
class comp
{
public:
    bool operator()(pair<int, action> a, pair<int, action> b)
    {
        if (a.first > b.first)
            return true;
        else if (a.first == b.first)
        {
            if (a.second.aid > b.second.aid)
                return true;
            else
                return false;
        }
        else
            return false;
    }
};
int shmid;
Node *graph;
int semid;
queue<action> shq; // shared queue for pushUpdate threads
queue<int> uq;
pthread_mutex_t sm = PTHREAD_MUTEX_INITIALIZER; // mutex for shared queue
pthread_cond_t sc = PTHREAD_COND_INITIALIZER;   // conditional variable for shared queue

map<int, int> pl[MAX_NODES];
pthread_mutex_t ms = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cs = PTHREAD_COND_INITIALIZER;

queue<action> wall[MAX_NODES];
priority_queue<pair<int, action>, vector<pair<int, action>>, comp> feed[MAX_NODES];
bool func(pair<int, int> a, pair<int, int> b)
{
    if (a.first > b.first)
        return true;
    else if (a.first == b.first)
    {
        if (a.second > b.second)
            return true;
        else
            return false;
    }
    else
        return false;
}
void *userSim(void *arg)
{
    while (1)
    {
        ofstream log_file;
        log_file.open("sns.log", ios_base::app);
        const int count = 100;
        set<int> s;
        while (s.size() < count)
        {
            s.insert(rand() % 37700);
        }
        log_file << "THE NODES THAT ARE RANDOMLY SELECTED: " << endl;
        cout << "THE NODES THAT ARE RANDOMLY SELECTED: " << endl;
        for (auto x : s)
        {
            log_file << x << " ";
            cout << x << " ";
        }
        log_file << endl;
        cout << endl;
        for (auto x : s)
        {
            int k = int(log2(graph[x].degree + 1));
            k = k * 10;
            int k1 = k;
            log_file << "The number of actions generated for node " << x << " of degree " << graph[x].degree << ": " << k << endl;
            cout << "The number of actions generated for node " << x << " of degree " << graph[x].degree << ": " << k << endl;
            log_file << "The actions generated: " << endl;
            cout << "The actions generated: " << endl;
            while (k--)
            {
                pthread_mutex_lock(&sm);
                action a;
                a.aid = k1 - k;
                a.at = rand() % 3;
                a.nid = x;
                a.t = time(NULL);
                vector<string> act;
                act.push_back("post");
                act.push_back("like");
                act.push_back("comment");
                log_file << act[a.at] << " ";
                cout << act[a.at] << " ";
                wall[x].push(a);
                shq.push(a);
                pthread_cond_signal(&sc);
                pthread_mutex_unlock(&sm);
            }
            log_file << endl;
            cout << endl;
        }
        log_file.close();
        sleep(120);
    }
}
void *pushUpdate(void *arg)
{
    while (true)
    {
        ofstream log_file;
        log_file.open("sns.log", ios_base::app);
        pthread_mutex_lock(&sm);
        while (shq.empty())
        {
            pthread_cond_wait(&sc, &sm);
        }
        action a = shq.front();
        shq.pop();
        pthread_mutex_unlock(&sm);
        int ni = a.nid;
        for (int i = 0; i < graph[ni].nb.size(); i++)
        {
            int j = graph[ni].nb[i];
            pthread_mutex_lock(&ms);
            uq.push(j);
            if (graph[j].cat == 0)
                feed[j].push({0, a});
            else
                feed[j].push({pl[j][a.nid], a});
            pthread_cond_signal(&cs);
            pthread_mutex_unlock(&ms);
        }
        vector<string> act;
        act.push_back("post");
        act.push_back("like");
        act.push_back("comment");

        cout << a.nid << " pu " << act[a.at] << " " << a.aid << " " << a.t << endl;
        log_file << a.nid << " pu " << act[a.at] << " " << a.aid << " " << a.t << endl;
        log_file.close();
    }
    pthread_exit(NULL);
}
void *readPost(void *arg)
{
    while (true)
    {
        ofstream log_file;
        log_file.open("sns.log", ios_base::app);
        pthread_mutex_lock(&ms);
        while (uq.empty())
        {
            pthread_cond_wait(&cs, &ms);
        }
        int nid = uq.front();
        uq.pop();
        vector<string> act;
        act.push_back("post");
        act.push_back("like");
        act.push_back("comment");
        while (!feed[nid].empty())
        {
            int prio = feed[nid].top().first;
            action a = feed[nid].top().second;
            feed[nid].pop();
            if (graph[nid].cat == 1)
            {
                cout << nid << ": "
                     << "I read action id " << a.aid << " of type " << act[a.at] << " by the user " << a.nid << " at time " << a.t << " has priority " << prio << endl;
                log_file << nid << ": "
                         << "I read action id " << a.aid << " of type " << act[a.at] << " by the user " << a.nid << " at time " << a.t << " has priority " << prio << endl;
            }
            else
            {
                cout << nid << ": "
                     << "I read action id " << a.aid << " of type " << act[a.at] << " by the user " << a.nid << " at time " << a.t << endl;
                log_file << nid << ": "
                         << "I read action id " << a.aid << " of type " << act[a.at] << " by the user " << a.nid << " at time " << a.t << endl;
            }
        }
        pthread_mutex_unlock(&ms);
        log_file.close();
    }
}
int main()
{
    pthread_mutex_init(&sm, NULL);
    pthread_mutex_init(&ms, NULL);
    pthread_cond_init(&sc, NULL);
    pthread_cond_init(&cs, NULL);
    graph = (Node *)malloc(sizeof(Node) * MAX_NODES);
    for (int i = 0; i < MAX_NODES; i++)
    {
        graph[i].id = i;
        graph[i].degree = 0;
        graph[i].cat = (rand() % 2);
    }
    ifstream file("musae_git_edges.csv");
    string line;
    getline(file, line);
    while (getline(file, line))
    {
        stringstream ss(line);
        string c;
        vector<int> a;
        while (getline(ss, c, ','))
        {
            int k = stoi(c);
            a.push_back(k);
        }
        graph[a[0]].degree++;
        graph[a[1]].degree++;
        graph[a[0]].nb.push_back(a[1]);
        graph[a[1]].nb.push_back(a[0]);
    }
    for (int i = 0; i < MAX_NODES; i++)
    {
        sort(graph[i].nb.begin(), graph[i].nb.end());
    }
    for (int i = 0; i < MAX_NODES; i++)
    {
        if (graph[i].cat == 0)
            continue;
        vector<pair<int, int>> st;
        for (int j = 0; j < graph[i].nb.size(); j++)
        {
            int b = graph[i].nb[j];
            int siz = (graph[i].nb.size() + graph[b].nb.size());
            vector<int> v(siz);
            vector<int>::iterator it;
            it = set_intersection(graph[i].nb.begin(), graph[i].nb.begin() + (graph[i].nb.size()),
                                  graph[b].nb.begin(), graph[b].nb.begin() + (graph[b].nb.size()),
                                  v.begin());
            int numb = it - v.begin();
            st.push_back(make_pair(numb, b));
        }
        sort(st.begin(), st.end(), func);
        for (int j = 0; j < st.size(); j++)
        {

            pl[i][st[j].second] = j;
        }
    }
    pthread_t us;
    pthread_create(&us, NULL, userSim, NULL);

    pthread_t pu[25], rp[10];
    for (int i = 0; i < 25; i++)
    {
        pthread_create(&pu[i], NULL, pushUpdate, NULL);
    }
    for (int i = 0; i < 10; i++)
    {
        pthread_create(&rp[i], NULL, readPost, NULL);
    }
    pthread_join(us, NULL);
    for (int i = 0; i < 25; i++)
    {
        pthread_join(pu[i], NULL);
    }
    for (int i = 0; i < 10; i++)
    {
        pthread_join(rp[i], NULL);
    }
}
//ReadPost function opens when lock on ms is opened and the queue is not empty and takes out the node id from uq and takes and displayes every action of the feed queue of that respective node and dequeues the node.
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdbool.h>

#define MAX_SLEEP_TIME 10 // maximum time a guest sleeps
#define MAX_STAY_TIME 20 // maximum time a guest stays in a room
#define MAX_CLEAN_TIME 15 // maximum time to clean a room

typedef struct {
    int guest_id; // ID of the guest occupying the room
    int stay_time; // Time the guest will stay in the room
    int occupancy;
    int occupancy_time;
} room;

extern room *rooms; // array of rooms
extern int num_guests; // number of guests currently in the hotel
extern int num_rooms; // number of rooms in the hotel
extern sem_t *guest_sem; // semaphore to control guest access to rooms
extern sem_t *clean_sem; // semaphore to control cleaning staff access to rooms
extern int *pri;
extern bool *stat;
//int count;

void *cleaner_thread(void *arg) {
    int clean_id = *((int *) arg);
    free(arg);
    while (true) {
        // Wait for a room with occupancy of 2
        int room_index = -1;
       int count = 0;
        for (int i = 0; i < num_rooms; i++) {
            
            if (rooms[i].occupancy == 2) {
                count++;
            }
          
        }
         int count1 = 0;
        for (int i = 0; i < num_rooms; i++) {
            
            if (stat[i] == true) {
                count1++;
            }
          
        }

   if(count1 == num_rooms)
   {
    for (int j = 0 ; j < num_rooms; j++)
    {
        stat[j] = false;
       sem_post(&guest_sem[j]);
    }         

   }
   else 
   {if (count == num_rooms) {
            //count = 0;
            for (int i = 0; i < num_rooms; i++) {
            if(stat[i] == false )
            {
            stat[i] = true;
            room_index = i;
            sem_wait(&clean_sem[room_index]);
            // Clean the room
            if(rooms[i].occupancy != 0)
            {
                printf("Cleaning staff %d is cleaning room %d\n",clean_id, room_index);
            //printf("%d\n",count);
            int clean_time = rooms[room_index].stay_time*0.5;
            sleep(clean_time);
             rooms[room_index].guest_id = -1;
            rooms[room_index].stay_time = 0;
            rooms[room_index].occupancy = 0;
            printf("Cleaning staff %d finished cleaning room %d in %d seconds\n",clean_id, room_index, clean_time);
            }
            
           sem_post(&clean_sem[room_index]);
            
            }
            }

        }
   }

        //  else {
        //     // No rooms to clean, take a break
        //     int sleep_time = rand() % MAX_SLEEP_TIME + 1;
        //     printf("Cleaning staff is taking a break for %d seconds\n", sleep_time);
        //     sleep(sleep_time);
        // }
        
    }
}

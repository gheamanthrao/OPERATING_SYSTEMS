#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdbool.h>

#define MAX_SLEEP_TIME 10 // maximum time a guest sleeps
#define MAX_STAY_TIME 20 // maximum time a guest stays in a room
#define MAX_CLEAN_TIME 15 // maximum time to clean a room

typedef struct {
    int guest_id; // ID of the guest occupying the room
    int stay_time; // Time the guest will stay in the room
    int occupancy;
    int occupancy_time;
} room;

extern room *rooms; // array of rooms
extern int num_guests; // number of guests currently in the hotel
extern int num_rooms; // number of rooms in the hotel
extern sem_t *guest_sem; // semaphore to control guest access to rooms
extern sem_t *clean_sem; // semaphore to control cleaning staff access to rooms
extern int *pri;
extern bool *stat;
int loop = 0;

void *guest_thread(void *arg) {
    int guest_id = *((int *) arg);
    free(arg);
    //srand(time(NULL));
    loop++;
    int priority = rand() % num_guests + 1;
     
    while (true) {
        int sleep_time = rand() % MAX_SLEEP_TIME + 1;
        printf("Guest %d is sleeping for %d seconds\n", guest_id, sleep_time);
        sleep(sleep_time);

        int stay_time = rand() % (MAX_STAY_TIME - 10 + 1) + 10;
        printf("Guest %d wants a room for %d seconds\n", guest_id, stay_time);
   for (int i = 0 ; i < num_rooms ; i++)
   {
  sem_wait(&clean_sem[i]);
   }
       
         int prev_guest_id;
        bool room_found = false;
        int room_index = -1;

        for (int i = 0; i < num_rooms; i++) {
            sem_wait(&guest_sem[i]);
           
            if (rooms[i].guest_id == -1 && rooms[i].occupancy != 2) {
                rooms[i].guest_id = guest_id;
                rooms[i].stay_time += stay_time;
                
                //stat[i] = false;
                //rooms[i].occupancy_time = 
                room_index = i;
                if(loop == 1)
                {
                    pri[i] = i+1;
                }
                else {pri[i] = priority;}
                room_found = true;
                break;
            } 
            sem_post(&guest_sem[i]);
        }
        if (room_found != true){
        for (int i = 0; i < num_rooms; i++) {
               sem_wait(&guest_sem[i]);
           if (rooms[i].occupancy == 1 && priority >= pri[i] + 1) {
                prev_guest_id = rooms[i].guest_id;
                rooms[i].guest_id = guest_id;
                rooms[i].stay_time = stay_time;
                
                 if(loop == 1)
                {
                    pri[i] = i+1;
                }
                else {pri[i] = priority;}
                //stat[i] = false;
                room_index = i;
                room_found = true;
                printf("Guest %d with priority %d replaced guest %d in room %d\n", guest_id, pri[i], prev_guest_id, i);
                break;
            }
             sem_post(&guest_sem[i]);
        }
        }

         for (int i = 0 ; i < num_rooms ; i++)
   {
  sem_post(&clean_sem[i]);
   }
        

        if (room_found == true) {
            printf("Guest %d with priority %d got room %d with stay time %d\n", guest_id, pri[guest_id], room_index, stay_time);
            rooms[room_index].occupancy++;
            sem_post(&guest_sem[room_index]); // Release the room semaphore
            sleep(stay_time);
            
            sem_wait(&guest_sem[room_index]);
            rooms[room_index].guest_id = -1;
            
            //rooms[room_index].stay_time = ;
            //rooms[room_index].occupancy = 0;
            sem_post(&guest_sem[room_index]);
        } else {
            printf("Guest %d with priority %d could not find a room\n", guest_id, priority);
            for (int i = 0; i < num_rooms; i++) {
                sem_post(&guest_sem[i]);
            }
        }
    }

    return NULL;
}

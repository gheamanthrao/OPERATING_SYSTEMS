#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdbool.h>

#define MAX_SLEEP_TIME 10 // maximum time a guest sleeps
#define MAX_STAY_TIME 20 // maximum time a guest stays in a room
#define MAX_CLEAN_TIME 15 // maximum time to clean a room

typedef struct {
    int guest_id; // ID of the guest occupying the room
    int stay_time; // Time the guest will stay in the room
    int occupancy;
    int occupancy_time;
} room;

room *rooms; // array of rooms
int num_guests = 0; // number of guests currently in the hotel
int num_rooms = 0; // number of rooms in the hotel
int num_cleaners = 0; // number of cleaning staff in the hotel
sem_t *guest_sem; // semaphore to control guest access to rooms
sem_t *clean_sem; // semaphore to control cleaning staff access to rooms
int *pri;
bool *stat;

void *guest_thread(void *arg);
void *cleaner_thread(void *arg);

int main() {
   
   srand(time(NULL));

     printf("Enter the number of rooms : ");
     scanf("%d/n",&num_rooms);
      printf("Enter the number of cleaners : ");
     scanf("%d/n",&num_cleaners);
      printf("Enter the number of guests : ");
     scanf("%d/n",&num_guests);
     printf("\n");

     if(num_cleaners >= num_rooms ||num_rooms >=  num_guests|| num_guests <= 1 || num_cleaners <= 1 || num_rooms <= 1 )
     {
        printf("Invalid Inputs \n");
        return 0;
     }


    // Initialize the array of rooms
    rooms = (room *) malloc(sizeof(room) * num_rooms);
    for (int i = 0; i < num_rooms; i++) {
        rooms[i].guest_id = -1;
        rooms[i].stay_time = -1;
        rooms[i].occupancy =0;
    }
     
    pri =  malloc(sizeof(int)*num_guests);
    for (int i = 0; i < num_guests; i++)
    {
        pri[i] = num_guests-i;
    }

    stat = (bool*) malloc(sizeof(bool) * num_cleaners);
     for (int i = 0; i < num_cleaners; i++)
    {
      stat[i] = false;
    }
    // Initialize the guest semaphore
    guest_sem = (sem_t *) malloc(sizeof(sem_t) * num_rooms);
    for (int i = 0; i < num_rooms; i++) {
        sem_init(&guest_sem[i], 0, 1);
    }
     clean_sem = (sem_t *) malloc(sizeof(sem_t) * num_rooms);
    for (int i = 0; i < num_rooms; i++) {
        sem_init(&clean_sem[i], 0, 1);
    }
    // Initialize the cleaning staff semaphore
    //sem_init(&clean_sem, 0, 1);

    // Create the guest threads
    pthread_t *guest_threads = (pthread_t *) malloc(sizeof(pthread_t) * num_guests);
    for (int i = 0; i < num_guests; i++) {
        int *guest_id = (int *) malloc(sizeof(int));
        *guest_id = i;
        pthread_create(&guest_threads[i], NULL, guest_thread, guest_id);
    }

    // Create the cleaning staff threads
    pthread_t *cleaner_threads = (pthread_t *) malloc(sizeof(pthread_t) * num_cleaners);
    for (int i = 0; i < num_cleaners; i++) {
        int *cleaner_id = (int *) malloc(sizeof(int));
        *cleaner_id = i;
        pthread_create(&cleaner_threads[i], NULL, cleaner_thread, cleaner_id);
    }

    // Wait for the guest threads to finish
    for (int i = 0; i < num_guests; i++) {
        pthread_join(guest_threads[i], NULL);
    }

    // Wait for the cleaning staff threads to finish
    for (int i = 0; i < num_cleaners; i++) {
        pthread_join(cleaner_threads[i], NULL);
    }

    // Free the resources
    free(rooms);
    free(guest_sem);
    free(guest_threads);
    free(cleaner_threads);

    return 0;
}


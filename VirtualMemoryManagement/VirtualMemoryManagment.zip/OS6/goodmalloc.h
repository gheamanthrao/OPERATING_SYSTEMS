#ifndef MY_HEADER_FILE_H
#define MY_HEADER_FILE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
    int a;
    int b;
}range;

typedef struct lr{
    range r;
    struct lr* next;
} range_list;
typedef struct ulr{
    range r;
    struct ulr* next;
    char* name;
    int flg;
} used_list;
typedef struct element{
int data;
struct element *prev;
struct element *next;
}element;

typedef struct memS{
    char* a[100];
    int lev;
    struct memS *next;
    int nn;
}stack;

#define TABLE_SIZE 1000000 // size of hash table
#define MAX_NAME_LENGTH 100 // maximum length of a name
typedef struct{
    char name[MAX_NAME_LENGTH];
    long long int value;
    int index;
}entry;

// hash function
unsigned long hash(const char *str);
// create a new hash table entry
entry *new_entry(const char *name, long long int value, int size);

// insert a new key-value pair into the hash table
void insert(entry **table, const char *name, long long int value, int size);

// lookup the value corresponding to a given key
long long int lookup(entry **table, const char *name, int size);

// delete the entry corresponding to a given key
void delete(entry **table, const char *name);

long long int check(range_list *p, int fs, used_list* ul, char* name);

char* createMem(int size);

long long int createList(int size, char* name);

void assignVal(char* name, int index, int val);

void freeElem(void* name);

int getValue(char* name, int index);





#endif






#include "goodmalloc.h"


extern int level;
void merge(char* name, int l, int m, int r){
    level = level+1;
    int n1 = m-l+1;
    int n2 = r-m;
    createList(n1, "L");
    createList(n2, "R");
    int i,j,k;
    for(i = 0;i < n1;i++){
        assignVal("L",i,getValue(name,l+i));
    }
    for(j = 0;j < n2;j++){
        assignVal("R",j,getValue(name,m+1+j));
    }
    i = 0;
    j = 0;
    k = l;
    while(i < n1 && j < n2){
        if(getValue("L",i) <= getValue("R",j)){
            assignVal(name,k,getValue("L",i));
            i++;
        }
        else{
            assignVal(name,k,getValue("R",j));
            j++;
        }
        k++;
    }
    while(i < n1){
        assignVal(name,k,getValue("L",i));
        i++;
        k++;
    }
    while(j < n2){
        assignVal(name,k,getValue("R",j));
        j++;
        k++;
    }
    freeElem(NULL);
    level-=1;
    return;
}

void mergeSort(char* name, int l, int r){
    level = level+1;
    if(l < r){
        int m = (l+r)/2;
        mergeSort(name, l, m);
        mergeSort(name, m+1, r);
        merge(name, l, m, r);

    }
    level-=1;
}

int main(void)
{
	char* a = createMem(1024*1024*250);
    createList(50000,"array");
    for(int i = 0;i < 50000;i++){
        assignVal("array",i,(rand()%100000)+1);
    }
    printf("Before sorting\n");
    for(int i = 0;i < 50000;i++){
        printf("%d ",getValue("array",i));
    }
    printf("\n***********************\n");
    mergeSort("array",0,49999);
    for(int i = 0;i < 50000;i++){
        printf("%d ",getValue("array",i));
    }
	return 0;
}

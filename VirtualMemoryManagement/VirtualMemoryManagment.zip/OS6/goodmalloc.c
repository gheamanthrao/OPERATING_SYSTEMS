#include "goodmalloc.h"



entry** table;

stack* glob;
int level = 0;

unsigned long hash(const char *str){
    unsigned long hash = 5381;
    int c;
    while ((c = *str++))
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
    return hash;
}

// create a new hash table entry
entry *new_entry(const char *name, long long int value,int size) {
    entry *e = malloc(sizeof(entry));
    strncpy(e->name, name, MAX_NAME_LENGTH);
    e->value = value;
    e->index = size;
    return e;
}

// insert a new key-value pair into the hash table
void insert(entry **table, const char *name, long long int value,int size) {
    unsigned long index = (hash(name)) % TABLE_SIZE;
    if (table[index] == NULL) {
        // if the index is empty, create a new entry
        table[index] = new_entry(name, value,size);
    } else {
        // if the index is not empty, resolve collisions with linear probing
        while (table[index] != NULL) {
            index = (index + 1) % TABLE_SIZE;
        }
        
        table[index] = new_entry(name, value,size);
    }
}

// lookup the value corresponding to a given key
long long int lookup(entry **table, const char *name,int size) {
    unsigned long index = hash(name) % TABLE_SIZE;
    while (table[index] != NULL) {
        if (strcmp(table[index]->name, name) == 0) {
            if(size < (table[index]->index)) return table[index]->value;
        }
        index = (index + 1) % TABLE_SIZE;
    }
    // if the key is not found, return an error value (-1 in this case)
    return -1;
}

// delete the entry corresponding to a given key
void delete(entry **table, const char *name) {
    unsigned long index = hash(name) % TABLE_SIZE;
    while (table[index] != NULL) {
        if (strcmp(table[index]->name, name) == 0) {
            // if the key is found, free the memory for the entry and set the index to NULL
            free(table[index]);
            table[index] = NULL;
            return;
        }
        index = (index + 1) % TABLE_SIZE;
    }
}
char* memory;
range_list* rl;
used_list* ul;
long long int check(range_list *p, int fs, used_list* ul, char* name){
    range_list* h = p;
    range_list *prev = p;
    long long int flag = 0;
    range_list* j;
    while(1){
        if(((h->r.b) - (h->r.a)) >= fs){
            j = (range_list*)malloc(sizeof(range_list));
            j->r.a = (h->r.a)+fs;
            j->r.b = h->r.b;
            j->next = NULL;
            if(h == prev){
                rl = j;
                j->next = h->next;
            }
            else{
                prev->next = j;
                j->next = h->next;
            }
            free(h);
            flag = 1;
            break;
        }
        else{
            prev = h;
            h = h->next;
        }
        if(h == NULL) break;
    }
    if(flag == 0) return 0;
    used_list* e = ul;
    used_list* pev = ul;
    
    if((e->r.a) == -1){
        e->r.a = 0;
        e->r.b = fs;
        e->name = (char*)malloc(strlen(name)+1);
        strcpy(e->name, name);
    }
    else{
        while(1){
            if((e->r.a) > (j->r.a)){
                used_list* k = (used_list*)malloc(sizeof(used_list));
                k->r.a = j->r.a-fs;
                k->r.b = j->r.a;
                k->name = (char*)malloc(strlen(name));
                strcpy(k->name, name);
                k->next = NULL;
                if(pev != e) pev->next = k;
                else ul = k;
                k->next = e;
                break;
            }
            else{
                pev = e;
                e = e->next;
            }
            if(e == NULL){
                used_list* k = (used_list*)malloc(sizeof(used_list));
                k->r.a = j->r.a-fs;
                k->r.b = j->r.a;
                k->name = (char*)malloc(strlen(name));
                strcpy(k->name, name);
                pev->next = k;
                k->next = NULL;
                break;
            }
        }
    }
    used_list* j1 = ul;
    while(1){
        if(j1 == NULL) break;
        j1 = j1->next;
    }
    int start = j->r.a-fs;
    int end = j->r.a;
    element* link_s = (element*)(memory + start);
    for(int i = 0; i < fs/sizeof(element); i++){
        element* link_e = (element*)(memory + start + sizeof(element));
        link_s->next = link_e;
        link_e->prev = link_s;
        link_s = link_e;
        start = start + sizeof(element);
    }
    link_s->next = NULL;
    return flag = j->r.a-fs+memory;
}

char* createMem(int size){
    table = malloc(TABLE_SIZE * sizeof(entry*));
    for (int i = 0; i < TABLE_SIZE; i++) {
        table[i] = NULL;
    }
    memory = (char*)malloc(size);
    range_list* p = (range_list*)malloc(sizeof(range_list));
    p->r.a = 0;
    p->r.b = size;
    p->next = NULL;
    rl = p;
    ul = (used_list*)malloc(sizeof(used_list));
    ul->r.a = -1;
    ul->r.b = -1;
    ul->next = NULL;
    // glob = NULL;
    return memory;
}
long long int createList(int size, char* name){

    int siz = size*sizeof(element);
    long long int flag = check(rl, siz, ul, name);
    if(flag == 0){
        printf("No space available\n");
        exit(0);
    }
    insert(table, name, flag, size);
    if(glob == NULL){
        stack* s = (stack*)malloc(sizeof(stack));
        s->next = glob;
        glob = s;
        glob->lev = level;
        glob->nn = 0;
        glob->a[glob->nn] = (char*)malloc(sizeof(char)*(strlen(name)+1));
        strcpy(glob->a[glob->nn], name);
        return flag;
    }
    if(glob->lev == level){
        glob->nn++;
        glob->a[glob->nn] = (char*)malloc(sizeof(char)*(strlen(name)+1));
        strcpy(glob->a[glob->nn], name);
    }
    else{
        stack* s = (stack*)malloc(sizeof(stack));
        s->next = glob;
        glob = s;
        glob->lev = level;
        glob->nn = 0;
        glob->a[glob->nn] = (char*)malloc(sizeof(char)*(strlen(name)+1));
        strcpy(glob->a[glob->nn], name);
    }
    return flag;
}
void assignVal(char* name, int index, int val){
    used_list* e = ul;
    while(1){
        if(strcmp(e->name, name) == 0){
            break;
        }
        else e = e->next;
        if(e == NULL) break;
    }
    if(e == NULL){
        printf("No such list");
        exit(0);
    }
    // if((index == 50000-3) || (index == 50000-2) || (index == 50000-1)) printf("%d\n",val);
    element* p = (element*)(memory + e->r.a);
    int i;
    for(i = 0; i < index; i++){
        p = p->next;
        if(p == NULL){
            printf("Excceded size of the array\n");
            exit(0);
        }
    }
    p->data = val;
    return;    
}
void freeElem(void* name){
    if(name != NULL){
        used_list* e = ul;
        used_list* prev = ul;
        int imt = 0;
        int sa,ea;
        while(1){
            if(e == NULL) break;
            if(strcmp(e->name, name) == 0){
                delete(table, name);
                if(prev == e){
                    sa = e->r.a;
                    ea = e->r.b;
                    free(e);
                    imt = 1;
                    break;
                }
                prev->next = e->next;
                sa = e->r.a;
                ea = e->r.b;
                free(e);
                imt = 1;
                break;
            }
            else{
                prev = e;
                e = e->next;
            }
        }
        if(imt == 0){
            printf("The respective array doesn't exist in the memory\n");
            exit(0);
        }
        range_list* i = rl;
        range_list* j = NULL;
        while(1){
            if(i == NULL) break;
            i = i->next;
        }
        i = rl;
        while(1){
            if(i == NULL){
                if(j->r.b == sa){
                    j->r.b = ea;
                }
                else{
                    range_list* new = (range_list*)malloc(sizeof(range_list));
                    new->r.a = sa;
                    new->r.b = ea;
                    j->next = new;
                }
                break;
            }
            if((i->r.a) >= ea){
                if(i->r.a == ea){
                    if(j == NULL){
                        i->r.a = sa;
                    }
                    else{
                        if(j->r.b == sa){
                            j->r.b = i->r.b;
                            j->next = i->next;
                            free(i);
                        }
                        else{
                            i->r.a = sa;
                        }
                    }
                }
                else{
                    if(j == NULL){
                        range_list* new = (range_list*)malloc(sizeof(range_list));
                        new->r.a = sa;
                        new->r.b = ea;
                        new->next = i;
                        
                        rl = new;
                        break;
                    }
                    if(j->r.b == sa){
                        j->r.b = ea;
                    }
                    else{
                        range_list* new = (range_list*)malloc(sizeof(range_list));
                        new->r.a = sa;
                        new->r.b = ea;
                        j->next = new;
                        new->next = i;
                    }
                }
                break;
            }
            else{
                j = i;
                i = i->next;
            }
        }
    }
    else{
        for(int i = 0;i <= glob->nn;i++){
            freeElem(glob->a[i]);
        }
        stack* temp = glob;
        glob = glob->next;
        free(temp);
    }
}

int getValue(char* name, int index){
    long long int ad = lookup(table, name, index);
    if(ad == -1){
        printf("The respective array doesn't exist in the memory or array access becomes difficult\n");
        exit(0);
    }
    element* p = (element*)(ad+(index*sizeof(element)));
    return p->data;
}


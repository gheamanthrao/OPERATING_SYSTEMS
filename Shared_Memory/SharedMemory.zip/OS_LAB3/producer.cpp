#include <iostream>
#include <vector>
#include <random>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <sys/wait.h>
#include <map>
#define MAX_NODES 5000
using namespace std;

typedef struct {
    int id;
    int degree;
    int neighbors[MAX_NODES];
} Node;



// shared memory segment and synchronization mechanisms
int shmid;
Node *graph;
int semid;


int main() {
    key_t key=9000;
    void *shm;

    // Generate a random seed
    random_device rd;
    mt19937 gen(rd());

    // Create a distribution for the number of new nodes to add
    uniform_int_distribution<> num_nodes_dist(10, 30);

    // Create a distribution for the number of existing nodes to connect to
    uniform_int_distribution<> num_edges_dist(1, 20);
    // Attach to the shared memory segment
    if ((shmid = shmget(key, MAX_NODES*sizeof(Node), 0666)) < 0) {
        perror("shmget");
        exit(1);
    }
    
    graph = (Node *)shmat(shmid, NULL, 0);
            int Num = 0;
        for (int i = 0; i <= MAX_NODES; i++) {
            if (graph[i].degree > 0) {
                Num++;
            }
        }
    int nodes=Num-1;
    // Cast the shared memory segment to a vector of vectors
  

    while (true) {
        // Sleep for 50 seconds
        sleep(50);
        for (int i = 0; i <= nodes; i++) {
        printf("Node %d: degree %d: ", graph[i].id,graph[i].degree);
        for (int j = 0; j < graph[i].degree; j++) {
            printf(" %d", graph[i].neighbors[j]);
        }
        printf("\n");
    }
       // cout<<"Hello\n";

        // Generate the number of new nodes to add
        int num_nodes = rand()%21 + 10;

        // Add the new nodes
        for (int i = 0; i < num_nodes; i++) {
        	nodes++;
            // Generate the number of existing nodes to connect to
            int num_edges = rand()%20 + 1;

   	map<int,int> edges;
 for (int j = 0; j < num_edges; j++) {edges[j]=0;} 
            
 int degree_sum = 0;           
 for (int j = 0; j < nodes; j++) {
            degree_sum += graph[j].degree; 
 }
 
// cout<<degree_sum<<endl;
            for (int j = 0; j < num_edges; j++) {
            
            int flag = 0;
            int existing_node_id;
            	while(!flag){
            	//cout<<"Hello\n";
            	int rand_degree = rand() % degree_sum + 1;
            	
            	int degree_so_far = 0; // sum of degrees so far
            	

            // find existing node with selected degree
            for (int l = 0; l < nodes ; l++) {
                degree_so_far += graph[l].degree; // add degree of existing node to sum
                if (degree_so_far >= rand_degree ) {
                    existing_node_id = graph[l].id; // found existing node
                    break;
                }
            }
            if(edges[existing_node_id]==0) flag = 1;
            	
            }
            	edges[existing_node_id]=1;
                graph[nodes].degree++;
                graph[nodes].neighbors[j] = existing_node_id;
                graph[existing_node_id].neighbors[graph[existing_node_id].degree++] = nodes;
        }
        }
        
    }

    // Detach from the shared memory segment
    shmdt(graph);

    return 0;
}


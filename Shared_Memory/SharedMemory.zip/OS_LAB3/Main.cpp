#include <iostream>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <fstream>
#include <sys/wait.h>
//#include "producer.h"


#define MAX_NODES 5000
using namespace std;

typedef struct {
    int id;
    int degree;
    int neighbors[MAX_NODES];
} Node;


// shared memory segment and synchronization mechanisms
int shmid;
Node *graph;
int semid;

int main() {
    // Create shared memory
  
    key_t key;
    char *shm, *s;
    key = 9000;

    if ((shmid = shmget(key, MAX_NODES*sizeof(Node), IPC_CREAT | 0666)) < 0) {
        perror("shmget");
        exit(1);
    }

    graph = (Node *)shmat(shmid, NULL, 0);
     for (int i = 0; i < MAX_NODES; i++) {
        graph[i].id = i;
        graph[i].degree = 0;        
    }


    
    string line;
    ifstream infile("facebook_combined.txt");
    while (getline(infile, line)) {
        int source, dest;
        sscanf(line.c_str(), "%d %d", &source, &dest);
       
        	graph[source].degree++;
                graph[dest].degree++;
                graph[source].neighbors[graph[source].degree - 1] = dest;
                graph[dest].neighbors[graph[dest].degree - 1] = source;
    }
    infile.close();
    int num_nodes = 0;
        for (int i = 0; i <= MAX_NODES; i++) {
            if (graph[i].degree > 0) {
                num_nodes++;
            }
        }
 for (int i = 0; i < num_nodes; i++) {
        printf("Node %d:", graph[i].id);
        for (int j = 0; j < graph[i].degree; j++) {
            printf(" %d", graph[i].neighbors[j]);
        }
        printf("\n");
    }
	
    //memcpy(shm, graph, sizeof(graph));
    int status;
    // Spawn producer and worker processes
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        exit(1);
    } else if (pid == 0) {
        //producer(shm);
         system("g++ producer.cpp -o producer");
         system("./producer");
         //sleep(5);
         printf("////////////////////////////////////");
        //exit(0);
    } else {
        // Wait for worker processes to finish
         //wait(NULL);
         system("g++ consumer.cpp -o consumer");
         system("./consumer");
        // Detach shared memory
      /* if (shmdt(graph) == -1) {
            perror("shmdt");
            exit(1);
        }

        // Destroy shared memory
        if (shmctl(shmid, IPC_RMID, NULL) == -1) {
            perror("shmctl");
            exit(1);
        }*/

        cout << "All workers have finished" << endl;
    }

    return 0;
}


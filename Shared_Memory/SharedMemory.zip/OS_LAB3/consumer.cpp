#include <iostream>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <fstream>
#include <sys/wait.h>
#include <limits.h>
#include <queue>
#include <algorithm>




#define MAX_NODES 5000

using namespace std;

typedef struct {
    int id;
    int degree;
    int neighbors[MAX_NODES];
} Node;
 
// shared memory segment and synchronization mechanisms
int shmid;
Node *graph;
Node *g;
int semid;
pid_t *pidArr;


void dij(vector<int> &cp,int nn,vector<vector<vector<int>>> &p,int cpn){
    string filename = "consumer_" + to_string(cpn+1) + ".txt";
    ofstream outfile;
    outfile.open(filename, ios_base::app);
    vector<int> dist(MAX_NODES, INT_MAX);
    vector<int> prev(MAX_NODES, -1);
    vector<int> er(MAX_NODES,0);
    for(auto & ele : cp){
        prev[ele] = -1;
        er[ele] = 1;
        if(g[ele].degree > 0){
            vector<bool> visited(MAX_NODES, false);
            dist[ele] = 0;
            priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
            pq.push({0, ele});
            while(!pq.empty()){
                int u = pq.top().second;
                pq.pop();
                if (visited[u]) {
                    continue;
                }
                visited[u] = true;
                for (int j = 0; j < g[u].degree; j++) {
                    int v = g[u].neighbors[j];
                    int weight = 1;
                    if (dist[u] + weight < dist[v]) {
                        dist[v] = dist[u] + weight;
                        prev[v] = u;
                        pq.push({dist[v], v});
                    }
                }
            }
        }
    }
    vector<vector<int>> out(MAX_NODES);
    for(int i = 0;i < nn;i++){
        if(er[i] == 1) continue;
        int cn = i;
        vector<int> output;
        output.push_back(cn);
        while(prev[cn] != -1){
            output.push_back(prev[cn]);
            cn = prev[cn];
        }
        reverse(output.begin(),output.end());
        for(int i=0;i<output.size();i++){
            outfile << output[i] <<" ";
        }
        outfile << endl;
        out[i] = output;
    }
    p[cpn] = out;
    outfile.close();
    return;
}
void jid(vector<int> &cp,int nn,vector<vector<vector<int>>> &p,int cpn,int pn,int k){
    vector<int> dist(MAX_NODES, INT_MAX);
    vector<int> er(MAX_NODES,0);
    vector<int> prev(MAX_NODES, -1);
    for(int i = 0;i < cp.size();i++) er[cp[i]] = 1;
    for(int i = pn;i < cp.size();i++){
        int ele = cp[i];
        prev[ele] = -1;
        if(g[ele].degree > 0){
            vector<bool> visited(MAX_NODES, false);
            dist[ele] = 0;
            priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
            pq.push({0, i});
            while(!pq.empty()){
                int u = pq.top().second;
                pq.pop();
                if (visited[u]) {
                    continue;
                }
                visited[u] = true;
                for (int j = 0; j < g[u].degree; j++) {
                    int v = g[u].neighbors[j];
                    int weight = 1;
                    if (dist[u] + weight < dist[v]) {
                        dist[v] = dist[u] + weight;
                        prev[v] = u;
                        pq.push({dist[v], v});
                    }
                }
            }
        }
    }
    vector<vector<int>> out = p[cpn];
    // for(int i = 0;i < k;i++){
    //     if(er[i] == 1) continue;
    //     int cn = i;
    //     vector<int> output;
    //     output.push_back(cn);
    //     while(prev[cn] != -1){
    //         output.push_back(prev[cn]);
    //         cn = prev[cn];
    //     }
    //     reverse(output.begin(),output.end());
    //     if(out[i].size() > output.size()) out[i] = output;
    // }


    // cout<<"hi1"<<endl;
    for(int i = k;i < nn;i++){
        if(er[i] == 1) continue;
        int min = INT_MAX;
        int ind;
        int nnode;
        for (int j = 0; j < g[i].degree; j++) {
            int v = g[i].neighbors[j];
            if(min > out[v].size()){
                min = out[v].size();
                ind = v;
                nnode = v;
            }
        }
        vector<int> p1 = out[ind];
        if(p1.size() == 0) p1.push_back(nnode);
        p1.push_back(i);
        out[i] = p1;
    }
    string filename = "consumer_" + to_string(cpn+1) + ".txt";
    ofstream outfile;
    outfile.open(filename);
    p[cpn] = out;
    for(int i = 0;i < nn;i++){
        for(int j = 0;j < p[cpn][i].size();j++){
            outfile<<p[cpn][i][j] <<" ";
        }
        if(p[cpn][i].size() != 0) outfile<<endl;
    }
    outfile.close();
    return;
}






void consumer(int worker_id, int start_node_id, int end_node_id) {
   

        // Count the current number of nodes in the graph
        int num_nodes = 0;
        for (int i = 0; i <= MAX_NODES; i++) {
            if (graph[i].degree > 0) {
                num_nodes++;
            }
        }

        // Run Djkstra’s shortest path algorithm
        // TODO: Implement Djkstra’s shortest path algorithm

        // Write the set of edges depicting the shortest path to each reachable node from the source node
        // along with the source node to a file
      string filename = "consumer_" + to_string(worker_id) + ".txt";
        // ofstream outfile;
        // outfile.open(filename, ios_base::app);
        ofstream outfile(filename, ios::trunc);
        int j=0;
          

        vector<int> dist(MAX_NODES, INT_MAX);
        vector<int> prev(MAX_NODES, -1);
 

        for (int i = start_node_id; i <= end_node_id; i++) {
                prev[i] = -1;
            
            if (graph[i].degree > 0) {
                // Find the shortest path from the start node to the current node using Djkstra's algorithm

                vector<bool> visited(MAX_NODES, false);

                dist[i] = 0;

                priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
                pq.push({0, i});

                while (!pq.empty()) {
                    int u = pq.top().second;
                    pq.pop();

                    if (visited[u]) {
                        continue;
                    }
                    visited[u] = true;

                    for (int j = 0; j < graph[u].degree; j++) {
                        int v = graph[u].neighbors[j];
                        int weight = 1;

                        if (dist[u] + weight < dist[v]) {
                            dist[v] = dist[u] + weight;
                            prev[v] = u;
                            pq.push({dist[v], v});
                        }
                    }
                }
            }
        }
                // Write the shortest path to the output file
                //outfile << start_node_id << " ";
            for(int k=0;k<num_nodes;k++){
                if(k<start_node_id || k>end_node_id){
                int curr_node = k;
                 vector<int> output;
                  output.push_back(curr_node);
                while (prev[curr_node] != -1) {
                
                    //outfile << prev[curr_node] << " ";
                    output.push_back(prev[curr_node]);
                    curr_node = prev[curr_node];
                   
                    
                }
                reverse(output.begin(),output.end());
                for(int i=0;i<output.size();i++){
                  outfile << output[i] <<" ";
                }
                outfile << endl;
            }
}
        
        
        outfile.close();
    

    // Notify parent process that consumer is done
    pidArr[getpid() - 1] = 0;
}

void optimize()
{
    int nn = 0;
    key_t key;
    char *shm, *s;
    key = 9000;

    if ((shmid = shmget(key, MAX_NODES * sizeof(Node), 0666)) < 0)
    {
        perror("shmget");
        exit(1); 
    }
    g = (Node *)shmat(shmid, NULL, 0);
    for(int i = 0;i < MAX_NODES;i++){
        if(g[i].degree > 0){
            nn++;
        }
    }
    int pn = nn;
    vector<vector<int>> cp(10);
    int k = nn/10;
    int ln = 0;
    for(int i = 0;i < 10;i++){
        for(int j = 0;j < k;j++) cp[i].push_back(j+ln);
        ln += k;
    }
    int no = nn - (k*10);
    for(int i = 0;i < no;i++) cp[i].push_back(ln++);
    vector<vector<vector<int>>> p(10);
    for(int i = 0;i < 10;i++){
        dij(cp[i],nn,p,i);
    }
    shmdt(g);
    while(1){
        sleep(30);
        nn = 0;
        if ((shmid = shmget(key, MAX_NODES * sizeof(Node), 0666)) < 0)
        {
            perror("shmget");
            exit(1);
        }
        g = (Node *)shmat(shmid, NULL, 0);
        for(int i = 0;i < MAX_NODES;i++){
            if(g[i].degree > 0){
                nn++;
            }
        }
        if(pn == nn) continue;
        int k = pn;
        vector<int> b(10);
        for(int i = 0;i < 10;i++) b[i] = cp[i].size();
        for(int i = pn;i < nn;i++){
            int min = INT_MAX,ind;
            for(int j = 0;j < 10;j++){
                if(min > cp[j].size()){
                    min = cp[j].size();
                    ind = j;
                }
            }
            cp[ind].push_back(i); 
        }
        for(int i = 0;i < 10;i++){
            jid(cp[i],nn,p,i,b[i],pn);
        }
        pn = nn;
        shmdt(g);
    }
    if (shmctl(shmid, IPC_RMID, NULL) == -1) {
        perror("shmctl");
        exit(1);
    }
}


int main(int argc, char* argv[]) { 
    // Create shared memory

    if(argc>1){
            	optimize();
                return 0;
            }
    key_t key;
    char *shm, *s;
    key = 9000;

    if ((shmid = shmget(key, MAX_NODES*sizeof(Node),  0666)) < 0) {
        perror("shmget");
        exit(1);
    }
    //cout << MAX_NODES*sizeof(Node) << endl;
    //cout << "1" << endl;
    graph = (Node *)shmat(shmid, NULL, 0);
    // for (int i = 0; i < MAX_NODES; i++) {
    //     graph[i].id = i;
    //     graph[i].degree = 0;
    // }
 //cout << "1" << endl;
//     string line;
//     ifstream infile("fb1.txt");
//     while (getline(infile, line)) {
//         int source, dest;
//         sscanf(line.c_str(), "%d %d", &source, &dest);

//         graph[source].degree++;
//         graph[dest].degree++;
//         graph[source].neighbors[graph[source].degree - 1] = dest;
//         graph[dest].neighbors[graph[dest].degree - 1] = source;
//     }
//     infile.close();
//    cout << "1" << endl;
    // Spawn worker
    while(true){
      
    int k =10;
    int start_node_id = 0;

            int num_nodes = 0;
        for (int i = start_node_id; i <= MAX_NODES; i++) {
            if (graph[i].degree > 0) {
                num_nodes++;
            }
        }
 int max_nodes = num_nodes;
    while(k>= 1){

      
        int end_node_id = start_node_id + num_nodes/k;
      
        pid_t pid = fork();

        if (pid < 0) {
            perror("fork");
            exit(1);
        } else if (pid == 0) {

            if(argc==1){
            consumer(10-k, start_node_id, end_node_id-1);
            exit(0);}
        }
    
     num_nodes = max_nodes-end_node_id;
     start_node_id = end_node_id;
  k--;
    }
      sleep(30);
    }
    // Wait for worker processes to finish
    for (int i = 0; i < 10; i++) {
        wait(NULL);
    }

    // Detach shared memory
if (shmdt(graph) == -1) {
perror("shmdt");
exit(1);
}

// Destroy shared memory
if (shmctl(shmid, IPC_RMID, NULL) == -1) {
    perror("shmctl");
    exit(1);
}

cout << "All workers have finished" << endl; 

 return 0;
}

 

